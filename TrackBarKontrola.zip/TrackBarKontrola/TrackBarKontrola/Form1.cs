﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrackBarKontrola
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {




        }
           

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void tbar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = tbar1.Value.ToString();
        }


        private void imeProgramaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Ime programa: track bar kontrola \n Ime i Prezime: Bruno Majdenic, 3d\n Datum: 22.1.2019.");
        }

        private void licencaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\n https://creativecommons.org/licenses/by-nc-sa/4.0/ \n Davatelj licence dopušta umnožavanje, distribuiranje i priopćavanje djela javnosti. Zauzvrat primatelji licence moraju imenovanjem priznati i označiti izvornog autora.");
        }
    }
    }


    
