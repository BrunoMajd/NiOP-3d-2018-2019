﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimerKomponenta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
 
            labelvrijeme.Text = DateTime.Now.ToShortTimeString();
            }

        private void oProgramuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ime programa: Timer Komponenta  \n Ime i Prezime: Bruno Majdenic, 3d\n Datum: 22.1.2019.");
        }

        private void licencaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\n https://creativecommons.org/licenses/by-nc-sa/4.0/ \n Davatelj licence dopušta umnožavanje, distribuiranje i priopćavanje djela javnosti. Zauzvrat primatelji licence moraju imenovanjem priznati i označiti izvornog autora.");
        }
    }
    }

