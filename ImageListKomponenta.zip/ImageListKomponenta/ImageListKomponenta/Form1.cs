﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageListKomponenta
{
    public partial class Form1 : Form
    {

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        public int brojac = 1;
        
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Image = lista.Images[0];
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (brojac % 2 == 0)
                pictureBox1.Image = lista.Images[0];
            else
                pictureBox1.Image = lista.Images[1];
            brojac++;
        }

        private void oProgramuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ime programa: Image List Komponenta \n Ime i Prezime: Bruno Majdenic, 3d\n Datum: 22.1.2018.");
        }

        private void licencaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\n https://creativecommons.org/licenses/by-nc-sa/4.0/ \n Davatelj licence dopušta umnožavanje, distribuiranje i priopćavanje djela javnosti. Zauzvrat primatelji licence moraju imenovanjem priznati i označiti izvornog autora.");
        }
    }
}

